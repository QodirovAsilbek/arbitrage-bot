# Crypto Arbitrage Bot

This bot compares crypto prices across Binance, Bitget, HTX, and MEXC.
